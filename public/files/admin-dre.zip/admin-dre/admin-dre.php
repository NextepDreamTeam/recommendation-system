<?php
/*
Plugin Name: Admin Dre
Plugin URI: <nolink>
Description: Manage user-access protected DRE from within WP
Version: 1.0
Author: Leonardo Visentin
Author URI: http://www.nextep.it
License: Nextep
*/
//SETUP
function admin_dre_install(){
    //Do some installation work
}
register_activation_hook(__FILE__,'admin_dre_install');
//1
function admin_dre_menu(){
	//add_options_page('Admin Dre Options', 'Admin Dre', 'manage_options', 'admin-dre-options-menu', 'admin_dre_options');
	add_menu_page('Dre', 'Admin Dre', 'administrator', 'admin-dre-menu', 'admin_dre_console');
	add_submenu_page('admin-dre-menu','Configuration', 'Configuration', 'administrator', 'admin-dre-options-menu', 'admin_dre_options');
}

function register_admin_dre_settings(){
	//register our settings
	register_setting( 'admin_dre-settings-group', 'admin_dre_username' );
	register_setting( 'admin_dre-settings-group', 'admin_dre_password' );
	register_setting( 'admin_dre-settings-group', 'admin_dre_action' );
}
//2

//3
function admin_dre_options(){
    include('admin/admin-dre-admin.php');
}


//HOOKS
add_action('init','admin_dre_init');
/********************************************************/
/* FUNCTIONS
********************************************************/
function admin_dre_init(){
    //do work
    run_sub_process();
	add_action('admin_menu','admin_dre_menu');
	add_action('admin_init','register_admin_dre_settings');
}

function run_sub_process(){
    //more work
}

function admin_dre_console(){
	if(get_option('admin_dre_action')!='' && get_option('admin_dre_username')!='' && get_option('admin_dre_password')!=''):
		include ('admin/admin-dre-console.php');
	else:
		include ('admin/admin-dre-unset.php');
	endif;
}
?>

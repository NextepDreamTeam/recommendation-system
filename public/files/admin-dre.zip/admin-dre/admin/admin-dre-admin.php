<?php


?>

<div class="wrap">
	<h2>Admin Dre</h2>
	<h3>Options</h3>
	
	
	<form method="post" action="options.php">

		<?php settings_fields( 'admin_dre-settings-group' ); ?>

		<?php do_settings_sections( 'admin_dre-settings-group' ); ?>

		<table class="form-table">

			<tr valign="top">

				<th scope="row" style="width:120px;">Username</th>

				<td><input type="text" style="width:360px;" name="admin_dre_username" value="<?php echo get_option('admin_dre_username'); ?>" /></td>

			</tr>

			<tr valign="top">

				<th scope="row" style="width:120px;">Password</th>

				<td><input type="password" style="width:360px;" name="admin_dre_password" value="<?php echo get_option('admin_dre_password'); ?>" /></td>

			</tr>

			<tr valign="top">

				<th scope="row" style="width:120px;">Login action</th>

				<td><input type="text" style="width:360px;" name="admin_dre_action" value="<?php echo get_option('admin_dre_action'); ?>" /><label style="display:block;color:#AAA;font-style:italic;font-size:12px;line-height:24px;" for="">Default url should be http://193.28.95.209/authenticate/userpass</label></td>

			</tr>

		</table>

		<?php submit_button(); ?>

	</form>

</div>
<?php


?>
<style>
#wpbody-content{padding-bottom:0;}
#wpfooter{display:none;}
#wpcontent, #wpfooter{margin-left:160px !important}
#iframe,#wpbody-content{width: 100%; height:99%; margin:0; min-height: 550px;}
</style>
<form style="display:none;" id="login" target="iframe" method="post" action="<?php print get_option('admin_dre_action'); ?>">
	<input type="hidden" name="username" value="<?php print get_option('admin_dre_username'); ?>" />
	<input type="hidden" name="password" value="<?php print get_option('admin_dre_password'); ?>" />
</form>
<iframe id="iframe" name="iframe"></iframe>

<script type="text/javascript">
	window.onload = function(){
		document.getElementById("login").submit();
		
		//jQuery(window).on('resize',windowDreResize);
		//windowDreResize();
	};
	function windowDreResize(){
		jQuery("#wpbody-content").css({height: jQuery(window).innerHeight() - 140});
		
		jQuery('#iframe body .navbar').css({'border-radius': 0});
	}
</script>
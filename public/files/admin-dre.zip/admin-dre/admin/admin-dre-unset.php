<?php

?>

<h3>Admin Dre configuration issue</h3>
<p>Please configure plugin first! You can do it <a href="admin.php?page=admin-dre-options-menu">here</a></p>
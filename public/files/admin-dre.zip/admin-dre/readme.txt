/**
 * (C) 2014 Visentin Leonardo
 *
 *	ADMIN DRE WP Plugin
 *	v1.0
 *	
 *	Package structure:
 *	
 *	admin-dre
 *	|
 *	|-- admin
 *	|	|
 *	|	|- admin-dre-admin.php
 *	|	|  (html for configuration page)
 *	|	|
 *	|	|- admin-dre-console.php
 *	|	|  (html for main DRE page)
 *	|	|
 *	|	|- admin-dre-unset.php
 *	|	|  (html for unset options)
 *	|
 *	|- admin-dre.php
 *	|  (main file)
 *	|
 *	|- readme.txt
 *	|  (this file)
 *
 *	This Wordpress plugin allows WP administrator to manage DRE from within the wordpress console
 *	Required options are username and password, and login URL to DRE
 *
 */